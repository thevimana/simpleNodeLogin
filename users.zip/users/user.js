var mongoose = require("mongoose");

var userShema = new mongoose.Schema({
    firstName : String,
    lastName : String,
    userId : {type:String, unique : true},
    password : String,
    created:{type:Date},
    modified:{type:Date}
});


module.exports = mongoose.model("User", userShema);