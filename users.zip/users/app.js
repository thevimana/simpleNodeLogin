var express  = require('express');
var bodyParser = require('body-parser');
var path = require('path');
// const mongodb = require("mongodb").MongoClient
// mongodb.connect('mongodb://localhost/users', function (err, db) {
//     console.log("Database connected");
//
// });

var mongoose = require("mongoose");

var app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended : false}));
app.use(express.static(path.join(__dirname, 'public')));

var User = require("./user");

var db = "mongodb://localhost/test";
mongoose.connect(db, { useMongoClient:true});
mongoose.connection.on('error', console.error.bind(console, 'mongodb connection error: '));

app.get("/", function(req, res)   {
    res.sendFile(__dirname +"/public/index.html");
});

app.post("/login", function (req, res) {
    User.find({userId:req.body.userId, password:req.body.password}, function (err, user) {
        console.log(user);
        if(err || user.length == 0) {
            res.status(404).send("User profile cannot be found");
        } else {
            res.sendFile(__dirname+"/public/welcome.html");
        }
    });
});

app.post('/register', function (req, res) {
    console.log(req.body.username);

    var newUser = new User({
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        userId: req.body.userId,
        password: req.body.password,
        created: Date.now(),
        modified: Date.now()
    });

    newUser.save(function (err) {
        if(err) {
            console.log(err);
            res.status(404).send("something went wrong, try again");
        }
        res.redirect("/");
    });

    // res.status(500).send(JSON.stringify(inputs));


});
app.listen(5000, function () {
console.log("Server is up and running on port 5000");
});